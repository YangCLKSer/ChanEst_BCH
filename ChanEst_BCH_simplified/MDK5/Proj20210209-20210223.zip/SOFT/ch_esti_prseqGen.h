#pragma once
#include "typedefs.h"
#include "datadefs.h"
#include "Array_Ctrl.h"

void de2bi(ARRAY_int32* out, int input, int bit_num, int type);
void ch_esti_prseqGen(ARRAY_int32* C, int lenC, int Cinit);
