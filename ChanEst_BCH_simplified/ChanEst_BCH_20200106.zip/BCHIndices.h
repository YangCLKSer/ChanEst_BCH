#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "typedefs.h"
#include "Array_Ctrl.h"
#include "datadefs.h"
#include <math.h>

extern void BCHIndices(ARRAY_int32* index_data, struct_ENB* enb);
