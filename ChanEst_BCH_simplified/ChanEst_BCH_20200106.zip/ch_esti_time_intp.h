#pragma once
#include "typedefs.h"
#include "Array_Ctrl.h"
#include "datadefs.h"
#include <math.h>

void ch_esti_time_intp(ARRAY_creal* hEst, const  ARRAY_real
    * locOFDMWithRS);